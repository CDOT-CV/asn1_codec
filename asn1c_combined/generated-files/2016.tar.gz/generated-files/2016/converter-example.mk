include ./generated-files/2016/Makefile.am.libasncodec

LIBS += -lm
CFLAGS += $(ASN_MODULE_CFLAGS) -DASN_PDU_COLLECTION -I.
ASN_LIBRARY ?= libasncodec.a
ASN_PROGRAM ?= converter-example
ASN_PROGRAM_SRCS ?= \
	./generated-files/2016/converter-example.c\
	./generated-files/2016/pdu_collection.c

all: $(ASN_PROGRAM)

$(ASN_PROGRAM): $(ASN_LIBRARY) $(ASN_PROGRAM_SRCS:.c=.o)
	$(CC) $(CFLAGS) $(CPPFLAGS) -o $(ASN_PROGRAM) $(ASN_PROGRAM_SRCS:.c=.o) $(LDFLAGS) $(ASN_LIBRARY) $(LIBS)

$(ASN_LIBRARY): $(ASN_MODULE_SRCS:.c=.o)
	$(AR) rcs $@ $(ASN_MODULE_SRCS:.c=.o)

%.o: %.c
	$(CC) $(CFLAGS) -o $@ -c $<

clean:
	rm -f $(ASN_PROGRAM) $(ASN_LIBRARY)
	rm -f $(ASN_MODULE_SRCS:.c=.o) $(ASN_PROGRAM_SRCS:.c=.o)

regen: regenerate-from-asn1-source

regenerate-from-asn1-source:
	asn1c -fcompound-names -gen-OER -fincludes-quoted -no-gen-JER -pdu=all -D ./generated-files/2016 ./scms-asn-files/EtsiTs103097ExtensionModule.asn ./scms-asn-files/Ieee1609Dot2.asn ./scms-asn-files/Ieee1609Dot2BaseTypes.asn ./scms-asn-files/Ieee1609Dot2Crl.asn ./scms-asn-files/Ieee1609Dot2CrlBaseTypes.asn ./j2735-asn-files/2016/J2735_201603DA_copyright_updated 12.2.asn ./semi-asn-files/2016/SEMI_v2.3.0.1_060325.asn

