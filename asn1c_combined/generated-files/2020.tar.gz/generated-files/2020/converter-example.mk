include ./generated-files/2020/Makefile.am.libasncodec

LIBS += -lm
CFLAGS += $(ASN_MODULE_CFLAGS) -DASN_PDU_COLLECTION -I.
ASN_LIBRARY ?= libasncodec.a
ASN_PROGRAM ?= converter-example
ASN_PROGRAM_SRCS ?= \
	./generated-files/2020/converter-example.c\
	./generated-files/2020/pdu_collection.c

all: $(ASN_PROGRAM)

$(ASN_PROGRAM): $(ASN_LIBRARY) $(ASN_PROGRAM_SRCS:.c=.o)
	$(CC) $(CFLAGS) $(CPPFLAGS) -o $(ASN_PROGRAM) $(ASN_PROGRAM_SRCS:.c=.o) $(LDFLAGS) $(ASN_LIBRARY) $(LIBS)

$(ASN_LIBRARY): $(ASN_MODULE_SRCS:.c=.o)
	$(AR) rcs $@ $(ASN_MODULE_SRCS:.c=.o)

%.o: %.c
	$(CC) $(CFLAGS) -o $@ -c $<

clean:
	rm -f $(ASN_PROGRAM) $(ASN_LIBRARY)
	rm -f $(ASN_MODULE_SRCS:.c=.o) $(ASN_PROGRAM_SRCS:.c=.o)

regen: regenerate-from-asn1-source

regenerate-from-asn1-source:
	asn1c -fno-include-deps -fcompound-names -fcase-insensitive-filenames -gen-OER -fincludes-quoted -no-gen-JER -pdu=all -D ./generated-files/2020 ./scms-asn-files/EtsiTs103097ExtensionModule.asn ./scms-asn-files/Ieee1609Dot2.asn ./scms-asn-files/Ieee1609Dot2BaseTypes.asn ./scms-asn-files/Ieee1609Dot2Crl.asn ./scms-asn-files/Ieee1609Dot2CrlBaseTypes.asn ./j2735-asn-files/2020/J2735-AddGrpB.asn ./j2735-asn-files/2020/J2735-AddGrpC.asn ./j2735-asn-files/2020/J2735-BasicSafetyMessage.asn ./j2735-asn-files/2020/J2735-Common.asn ./j2735-asn-files/2020/J2735-CommonSafetyRequest.asn ./j2735-asn-files/2020/J2735-EmergencyVehicleAlert.asn ./j2735-asn-files/2020/J2735-ITIS.asn ./j2735-asn-files/2020/J2735-IntersectionCollision.asn ./j2735-asn-files/2020/J2735-MapData.asn ./j2735-asn-files/2020/J2735-MessageFrame.asn ./j2735-asn-files/2020/J2735-NMEAcorrections.asn ./j2735-asn-files/2020/J2735-NTCIP.asn ./j2735-asn-files/2020/J2735-PersonalSafetyMessage.asn ./j2735-asn-files/2020/J2735-ProbeDataManagement.asn ./j2735-asn-files/2020/J2735-ProbeVehicleData.asn ./j2735-asn-files/2020/J2735-REGION.asn ./j2735-asn-files/2020/J2735-RTCMcorrections.asn ./j2735-asn-files/2020/J2735-RoadSideAlert.asn ./j2735-asn-files/2020/J2735-SPAT.asn ./j2735-asn-files/2020/J2735-SignalRequestMessage.asn ./j2735-asn-files/2020/J2735-SignalStatusMessage.asn ./j2735-asn-files/2020/J2735-TestMessage00.asn ./j2735-asn-files/2020/J2735-TestMessage01.asn ./j2735-asn-files/2020/J2735-TestMessage02.asn ./j2735-asn-files/2020/J2735-TestMessage03.asn ./j2735-asn-files/2020/J2735-TestMessage04.asn ./j2735-asn-files/2020/J2735-TestMessage05.asn ./j2735-asn-files/2020/J2735-TestMessage06.asn ./j2735-asn-files/2020/J2735-TestMessage07.asn ./j2735-asn-files/2020/J2735-TestMessage08.asn ./j2735-asn-files/2020/J2735-TestMessage09.asn ./j2735-asn-files/2020/J2735-TestMessage10.asn ./j2735-asn-files/2020/J2735-TestMessage11.asn ./j2735-asn-files/2020/J2735-TestMessage12.asn ./j2735-asn-files/2020/J2735-TestMessage13.asn ./j2735-asn-files/2020/J2735-TestMessage14.asn ./j2735-asn-files/2020/J2735-TestMessage15.asn ./j2735-asn-files/2020/J2735-TravelerInformation.asn ./semi-asn-files/2020/SEMI_v2.4.0.1_060325_j2020.asn

